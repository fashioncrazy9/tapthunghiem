This plugin blocks users from using a VPN (virtual private network) to change their IP address and/or location to anonymise them or bypass bans.

**Permissions:**

canvpn or rconadmin

canvpn.isp or rcon admin

**Chat Commands:**

/vwl "player name" to whitelist and allow VPN for player Flags : canvpn

/vuwl "player name" to un-whitelist player Flags needed : canvpn

/blisp "playername" used to do isp-bans Flags needed : canvpn.isp