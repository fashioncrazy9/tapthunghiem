Having trouble testing players, do they keep running away? Freeze players so that they can't move or run away while you test them.


/freeze <playername> to freeze the player

/unfreeze <playername> to unfreeze the player

````
grant user <name> canfreeze

revoke  user <name> canfreeze

grant group <name> canfreeze
````

Also credits to Zero for teaching me some things . I'm always up for advice and tips.