- allows you to change values of the different spawn managers

- console commands: **spawn.reload
**- Auto resets to default list every Protocol version change (most updates)**** (config is moved to .old)