The plugin automatically kick players with reserved or inappropriate names, that can be set into the config file.


You can whitelist a player giving him the permission "namefilter.allowed"


````
grant user <name> namefilter.allowed

revoke  user <name> namefilter.allowed

grant group <name> namefilter.allowed
````