Prevents guild members from doing damage to each other. Players who have nff on won't RECEIVE damage from other guild members. They CAN still do damage.


/nff on - Turns No Friendly Fire on for the player.

/nff off - Turns No Friendly Fire off for the player.