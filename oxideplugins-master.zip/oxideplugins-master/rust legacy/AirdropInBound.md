**OPTIONAL BUT RECOMMENDED:**
**[Location](http://oxidemod.org/plugins/location.937/) 1.0.0**


Show players when airdrops are incoming

**Features:**

- Choose to show the location's **name** (require Location plugin)

- Choose to show the **direction**

- Choose to show the **distance**

**AirdropInBound.json** config file

````
{

  "Messages: Wrong Arguments": "Wrong arguments, or target player doesn't exist",

  "Settings: Show direction to airdrop": true,

  "Settings: Show distance to airdrop": true,

  "Settings: Use Location Plugin http://oxidemod.org/plugins/location.937/ ": true

}
````