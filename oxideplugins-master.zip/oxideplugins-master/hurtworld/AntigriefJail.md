**AntiGriefJail** is a plugin for Hurtworld that gives the players the ability to moderate their own world. If a player experiences griefing from another player, simply give the griefer a ticket. If the griefer gets too many tickets then he is teleported to jail for an amount of time. Once the griefer has served his time, he is automatically let free.

**Player Commands**


* /sheriff  =>Basically a help command with basic information on how to use the plugin
* /giveticket => use this command to issue a griefer a ticket. If he gets enough tickets from enough players he will be sent to jail.


**Admin Commands**


* /setjailcoords => Set the coordinates to where the griefer will be teleported. As the server admin, stand on the position you want to set the coordinates to and then type this command. You will probably want to build a Jail around these coordinates.
* /getjailcoords => Shows the coordinates of the Jail in the chat window
* /setjailtime => Sets the number of seconds the griefer is to be confined in jail. (/setjailtime 300 will set the jail time to 5 minutes)
* /setticketcountforjail => Set the number of tickets a griefer needs to get before being sent to jail
* /gotojail => teleports the admin to jail


**ORIGINAL DEVELOPER**
[@sesmith2k](http://oxidemod.org/members/91888/)