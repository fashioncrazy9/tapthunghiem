This was originally made to mess with fellow admins, this plugin has the ability to remove any users godmode instantly without notice upon the use of the command (eventually going to be the ability to change this).


This is helpful if you have an admin running around with godmode on and he wont take it off, or you don't want to tell him. It will also give you a response about whether the targeted player had godmode removed or if the player wasn't found.


Use /ungod "user" to remove a players godmode.

The default permission to use this command is: antigod.allowed


Type this into the console to gain access: grant user/group "username/steamid" antigod.allowed


Looking into also removing the players armor slot items to incorporate invisible armor (which also grants god mode).


Based on PrincessRadPants' VEGod