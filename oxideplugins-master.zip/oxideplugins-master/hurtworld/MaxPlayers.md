**>>>>>> Setting maxplayers above 60 may cause severe performance issues. Use with caution! <<<<<<**

**MaxPlayers** is a simple plugin that allows you to increase the maximum players allowed on your server. The hard-coded limit in the game is 60, but you can set it up to 244 via this plugin.

**Usage**

This plugin replaces the default "maxplayers" console command, so just drop it under oxide/plugins and set "maxplayers #" like you normally would! As an added bonus, you can now change the max players while the server is running and players are connected.