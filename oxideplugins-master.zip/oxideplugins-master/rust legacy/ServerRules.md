Show server rules from config file when the command is run by a player.

**How to use the command:**

/rule

/rules


Displays:
Oxide : Rule 1
Oxide : Rule 2
Oxide : Rule 3


Image example: [http://i.imgur.com/TOUejXD.jpg](http://i.imgur.com/TOUejXD.jpg)