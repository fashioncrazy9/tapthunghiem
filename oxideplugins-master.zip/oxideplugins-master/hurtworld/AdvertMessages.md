**Advert Messages** are timed chat messages to work as informational messages.

**Configuration:**
Code (Java):
````
{

  "Messages": [

    "Welcome to our server, have fun!",

    "<orange>Need help?<end> Try calling for the <cyan>Admins<end> in the chat.",

    "Please, be respectful with to the other players.",

    "Cheating will result in a <red>permanent<end> ban.",

    "This server is running <orange>Oxide 2<end>."

  ],

  "Settings": {

    "Adverts Interval (In Minutes)": 12,

    "Broadcast To Console": true

  }
}
````