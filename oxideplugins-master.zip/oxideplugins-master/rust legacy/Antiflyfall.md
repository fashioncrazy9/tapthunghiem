This plugin is designed to teleport the player to the exact location in which he disconnected. This should stop a number of glitches cheaters use to day to glitch into bases such as the glitch through wall hack glitch for ceilings get ranticheat from reneb warning though this antiligch does not ban unless you set it to which i woudnt recomend as sometimes though rarely innocent players get banned


hackers that try to use this glitch is usually teleported to 0.0 0.0 0.0 in the middle of ironicly "Hacker valley" you can change it to just teleport to there last stable location or just ban but i woudnt recomend enabling the ban, the antiflyfall's bansystem is verry unstable.



but i would recommend this plugin to any server that has players who want there bases and there loot kept safe while they sleep this plugin prevents about 20 glitch raids a day infact if you were to tp to the location i gave you guys might find a bunch of sleeperss shacks etc.


Like my work? add me on steam and donate a game to me to show your love 
Flags needed:

cantpslper or rcon admin


Chat commands:

/tpslp "playername, dont forget the quotes are useful they are needed to do tp's to players with spaces in there names used to tp to offline players