Fly on your magic carpet!



**Commands:**
/fly XX => Fly !!! XX is the speed that you want. Default is 1.

using /fly 0 will stop your flying, and you will be able to move around

using /fly when flying will end your flying mode.

**Permissions:

rcon.login**

&

oxide permission: "**canfly**"


As you get teleported it can look a little glitchy, but it's the best that could be done on legacy