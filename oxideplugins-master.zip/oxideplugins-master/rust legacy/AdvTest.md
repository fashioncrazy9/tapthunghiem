First version (v3) of the public released version of AdvTest.

**Commands:**


/test 'username' recoil

/test 'username' menu

/test 'username' bind

/test 'username' screenshot

/test 'username' fail

/test 'username' clear

**Permission: **advtest.allowed


Go to the FAQ page for information about whats being planned for the future!