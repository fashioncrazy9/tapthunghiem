With this plugin you can get player's information such ip, region, country and much more!

**Command:**

* /info <playername>
* /info time (to get the current time)
**Permission:**

* playerinfo.allowed
* Rcon