**Auto Admin **from greyhawk


As a logged in admin (rcon.login):
**/promote name** : name will be automatically set as admin on connect
**/demote name** : remove name from auto-admin


Auto-admins don't have to "F1 rcon.login" anymore