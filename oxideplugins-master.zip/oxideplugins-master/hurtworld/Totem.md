**Chat Commands:**

- /totem => get the list of your totems

- /totem TOTEMID => set a totem as next respawn
**Config file:**

````
{

  "Permission": "totem.use",

  "Totem list Refresh timer": 120,

  "Totem select cooldown": 300

}
````