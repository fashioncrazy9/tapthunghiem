**Description**

This plugin allows all users to send private messages to each other

**Usage**

/pm <name> <message>

/r <message> -- this replies to the last person you got a pm from