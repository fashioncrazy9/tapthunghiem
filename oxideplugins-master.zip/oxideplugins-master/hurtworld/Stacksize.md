There's no permission or messages for this plugin.


Just use the config file to set your stacksize and /reload the plugin.


````

{

  "Backpacks": 1,

  "BlastFurnace": 1,

  "C4": 1,

  "CarPanels": 1,

  "CarParts": 1,

  "ConstructionHammer": 1,

  "Designs": 1,

  "Drills": 1,

  "Dynamite": 5,

  "FreshOwrong": 1,

  "LandcrabMine": 1,

  "OwnershipStake": 1,

  "Paints": 1,

  "PoisonTrap": 1,

  "Sign": 1,

  "Steak": 1,

  "Wheels": 1,

  "Wrench": 1

}

 
````


**Important Notes:**

Before using any items, like car parts/paints etc, make sure you **only use one at a time.**


I have haven't tested which items disappear when a stack is used, so just use caution or test for yourself. I would appreciate posting here if you do 
The rotting/cooking of food is unchanged, so you can't cook an entire 255 stack of steak in a single shot. The same with Owrongs.

If you want to rot several Owrongs at the same time, you need to split them like before.