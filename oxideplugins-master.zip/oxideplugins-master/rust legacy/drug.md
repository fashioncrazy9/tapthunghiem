Changes the field of view of the player.

**Command**
/drug PLAYERNAME  to drug the player

/cure PLAYERNAME to cure the player

**Credits**

Credits to Spicy and Pretermit for the original plugin for Oxide 1.18.

Also credits to Wulf for helping me with rust.RunClientCommand

**Permission **

grant user PLAYERNAME candrug

revoke user PLAYERNAME candrug

grant group GROUPNAME candrug

revoke.group GROUPNAME candrug