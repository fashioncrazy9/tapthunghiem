This plugin let player know who talks (with voice chat) around him.

No configuration file yet. It pops up every 3 secs inventory notice.