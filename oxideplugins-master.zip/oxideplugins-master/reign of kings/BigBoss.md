In this mod, you can (if you are an admin, of course) assign a player to be the "Boss", which will give him huge damage reduction and increased damage output.


Then try and take him down along with a bunch of other mates in a melee brawl to end all others!


/setboss <playername> - set the player boss

/removeboss <boss number> - remove the specified boss

/removeboss all - remove all bosses

/listboss - show a list of all the current bosses.