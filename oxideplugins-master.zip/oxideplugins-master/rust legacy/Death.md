**Death API**

This plugin aims to provide a way for future plugins to easily hook into rusts death system.


TBC