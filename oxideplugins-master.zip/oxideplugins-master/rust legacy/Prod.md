**REQUIRES: ** **[Player Database](http://oxidemod.org/plugins/player-database.927/) 1.0.1+




Features:**

- Get the Owner of a building

- Get the Owner of a deployable

- Get the list of players that have access to a door

**Command:**
- /prod => get owner steamid & names of owners of any deployables or structures

**How To:**

All data will start to be collected when you install the Player Database.

So you might not get all player names if you install this after a wipe.

Use /prod **while looking at the object**, it will tell you who the owner is.

If no owner is found it will just give you the steamid

**Lag:**

This doesnt use ANY hooks making this plugin 100% lag free

**To Do:**

- Last used

- Last connected player