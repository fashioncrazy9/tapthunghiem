**THIS IS FOR RUST LEGACY AND OXIDE 2.0

For Oxide 1.18: [R-Remover for Rust Legacy - Version History | Oxide](http://oxidemod.org/resources/r-remover.459/history) last compatible version is 3.2.2


OPTIONAL:
**[Share Database](http://oxidemod.org/plugins/share-database.935/) 1.0.0**



Features:**

- **Player** remove

- **Admin **remove

- **Global Structure **remove

- **Refund** option

- Set **Refund values**

- **Admin** remove & remove **all**

- **Choose **what you **allow **to be remove

- **Anti Float**

- Optional: **Share**

**Commands:**
- /remove admin optional:TIME => Activate Remove Admin Tool (hit with anything a building and the part will disappear)
- /remove all optional:TIME => will remove an entire building with all it's deployables
- /remove optional:TIME => this will work if you choose

- /remove targetplayername optional:TIME => give remove to a player

**Permissions:**

for /remove admin, all, and TargetPlayer
**rcon.login** or oxide permission: **canremove**


If you use the  **[Share Database](http://oxidemod.org/plugins/share-database.935/) 1.0.0**

players will be able to share bases and remove friends bases if they choose to.

You can grant a user permission by using:
**oxide.grant user <username> <permission>**

To create a group:
**oxide.group add <groupname>**

To assign permission to a group:
**oxide.grant group <groupname> <permission>**

To add users to a group:
**oxide.usergroup add <username> <groupname>**

To remove users permission:
**oxide.revoke <userid/username> <group> <permission>**Click to expand...

**Configs will get generated the first time you launch this plugin**

**TO DO:**

- anti remove while raiding

- uber hatchet super power!

- /remove steamid