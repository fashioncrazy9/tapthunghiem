**Chat Guard **allows you to block unwanted words and letters in the chat.

**Commands:**


* none


**Config file:**

````
{
"WordFilter": {

    "FilterList": [

      "fuck",

      "bitch",

      "faggot"

    ]

  }
}
````


**Future Updates:**


* your suggestions