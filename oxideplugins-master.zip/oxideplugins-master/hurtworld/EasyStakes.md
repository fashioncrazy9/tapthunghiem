**Permission:**

easystakes.use

****How to Add Permission:****

/grant user UserName easystakes.use


To grant permission for everyone use

/grant group default easystakes.use

**Commands:**

/stakes
This will show you how many stakes you have authority on, and how much amber you need to fill them all.


/stakes fill
This will fill every stake you are authorized too with amber from your inventory, until you run out of amber, or you fill them all, whichever comes first.