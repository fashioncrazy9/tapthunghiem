**Playtime Money** gives money to players for time on the server.


**Configfile (yourserver/oxide/config/PlaytimeMoney.json):**

````
{

  "Settings": {

    "Interval (in Minutes)": 10.0,

    "Money Amount": 25.0

  }
}
````



**Messagefile (yourserver/oxide/lang/en.PlaytimeMoney.json):**

````
{

  "Recieved Money": "You have recieved {amount}$ for playing on the server."
}
````