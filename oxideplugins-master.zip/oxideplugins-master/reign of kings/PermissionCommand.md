This plugin gives those with the appropriate permission (codehatch.command.admin.permissions) the ability to use the command again. 

Using the command without arguments will show all the available commands.