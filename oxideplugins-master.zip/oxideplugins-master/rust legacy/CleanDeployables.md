A remake from my clean up plugins from exp and legacy 1.18


This is NOT to use on buildings, you have the Remover Tool to remove buildings.

**Commands:**

- /clean DEPLOYABLENAME => clean all deployables on the server that are not close to any players building

- /clean bags => clean all lootsacks (bags) on the server that are not close to any players buildings

- /clean DEPLOYABLENAME all => force clean all deployables

- /clean bags all => clean all lootsacks


- /cleanradius RADIUS => clean all deployables (any type of deployables) around you in a Xm radius that are not close to any players buildings

- /cleanradius RADIUS bags => for bags

- /cleanradius RADIUS all => clean ALL deployables around you

- /cleanradius RADIUS DEPLOYABLENAME => clean all deployables around you that are not close to any players builgings

- /cleanradius RADIUS DEPLOYABLENAME/bags all => clean all deployables or bags around you.