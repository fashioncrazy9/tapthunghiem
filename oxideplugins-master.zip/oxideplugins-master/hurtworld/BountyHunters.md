**PLEASE CONSIDER DONATING TO SUPPORT DEVELOPMENT**


The plugin gives the ability to add bounties on Players.

**To view all bounties**

/bounties

/bounties top - Displays top 5 bounty hunters

**To add a bounty**

/addbounty playername bountyamount

/addbountyall amount - adds bounties to all online players (ADMINS ONLY)

**SPECIAL THANKS**

@[kpl35m](http://oxidemod.org/members/kpl35mm-nl.93043/)m-NL

For helping to beta test the plugin. You assistance is much appreciated.