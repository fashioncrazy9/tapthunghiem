This plugin allows players with permission to turn ON/OFF player damage.(Victim"player" between Attacker"player")

**(OXIDE)Permission** for the "/pdmg" command: "**canpdmg**"

{

/grant user PaiN canpdmg

/revoke user PaiN canpdmg

/grant group vip canpdmg

}


**Commands:**

/pdmg => Turns ON/OFF player damage.