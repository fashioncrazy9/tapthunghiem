**Features:**

- Become 100% invisible

- No Footstep Emitter (you can hear your own footsteps but others can't)

- Teleport back to where you were before when you deactivate the mod

**Commands:**

- /casper => activate deactivate the casper mod


This mod was inspired by Rust Essentials Ghost mod.