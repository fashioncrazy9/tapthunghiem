Reject players that have too many vac bans


Config: VACKicker.json

````
{

  "Messages: Too many VAC Bans": "You have too many VAC Bans to join this server",

  "Settings: Ban": true,

  "Settings: Max VAC allowed": 1,

  "STEAM API Key: http://steamcommunity.com/dev/apikey": ""

}
````