**Unlimited Ammo** allows players with permission to have unlimited ammo.

****

Permissions:****


* 
****unlimitedammo.use ****for using /toggleammo


**

How to grant permissions:**

Use following CHAT commands to grant permissions


* 
**/grant user <player> <permission>** grant permission to player
* 
**/grant group <group> <permission>** grant permission to group


**

Commands:**


* 
**/toggleammo** toggles unlimited ammo


**

Messagefile (yourserver/oxide/lang/en.UnlimitedAmmo.json):**

````
{

  "No Permission": "You don't have permission to use this command.",

  "Enabled": "You now have unlimited ammo!",

  "Disabled": "You no longer have unlimited ammo!"
}
````