PaiN Broadcast allows you to Broadcast messages to chat and also allows you to send a message to a specific player at the top of his screen.

**Commands:

/bcast** "**message**" --> Broadcast Messages to everyone.** [NEEDS PERMISSION]

/note** "**player**" "**message**" --> Send a message to a specific player at the top of his screen. **[NEEDS PERMISSION]**

**Permissions:**

"**canbroadcast**" --> Permission to be able to use the commands listed above.

**Default Config:**

````
{

  "Messages": {

    "BcastSyntax": "Syntax: /bcast \"message\" ",

    "ChatPrefix": "PaiN Broadcast",

    "NoPermission": "You do not have permission to use this command",

    "NoteSyntax": "Syntax: /note \"player\" \"message\" ",

    "PlayerNotFound": "Player Not Found!"

  }

}
````


**TODO:**

- Config (No time right now ..) = **DONE**