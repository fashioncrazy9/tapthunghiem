**- Auto resets to default list every Protocol version change (most updates)** (config is moved to .old)

- Console Commands:


* ****loot.reload****
* **loot.reset**
* **loot.stats**

StartingPick,

    RampBuilder,

    StorageLocker,

    Workbench,

    RawSteak,

    CookedSteak,

    RancidSteak,

    BoltAction,

    SandShoes,

    SandJacket,

    SandPants,

    SandHood,

    Ruby,

    SandGloves,

    LightBuilder,

    CottonSeed,

    Cotton,

    Flint,

    IronOre,

    Stone,

    Coal,

    Wood,

    WoodPlank,

    AnimalFat,

    AnimalPelt,

    Owrong,

    OwrongSeeds,

    Bark,

    Clay,

    IronIngot,

    IronPick,

    FirePit,

    TanningRack,

    FlintAxe,

    AnimalTendon,

    WeakString,

    ShapedIron,

    Anvil,

    ClayPot,

    AnvilCast,

    Water,

    MoltenIron,

    LimeStone,

    Flux,

    Lime,

    StrongString,

    RedHotIron,

    Bow,

    Arrow,

    PowerBow,

    MouldyOwrong,

    Ash,

    Bullet,

    Blastfurnace,

    IronPot,

    IronBlob,

    Sand,

    LiquidGlass,

    RangerJacket,

    RangerPants,

    RangerBoots,

    RangerHood,

    RangerGloves,

    HeavyArmorJacket,

    HeavyArmorPants,

    HeavyArmorBoots,

    HeavyArmorHelmet,

    HeavyArmorGloves,

    MediumArmorJacket,

    MediumArmorPants,

    MediumArmorBoots,

    MediumArmorHelmet,

    MediumArmorGloves,

    LightArmorJacket,

    LightArmorPants,

    LightArmorBoots,

    LightArmorHelmet,

    LightArmorGloves,

    IronAxe,

    GoldAxe,

    QualityIronPick,

    SteelPick,

    SnareBow,

    BoltActionCammo,

    BoltActionFancy,

    Leather,

    Glass,

    Amber,

    BackPack,

    StoneHatchet,

    DebugBackpack,

    ConstructionHammer,

    SuperPowerBow,

    OwnershipStake,

    GenericPants,

    GenericTorso,

    GenericBoots,

    FireTorch,

    AssaultRifle,

    Generator,

    TestPipeSource,

    Snood,

    Beanie,

    EmoHair,

    Sneakers,

    LongShirt,

    PineCone,

    TShirt,

    TShirt1,

    TShirt2,

    TShirt3,

    TShirt4,

    TShirt5,

    Hair2,

    Hair3,

    Moustache,

    BluBeanie,

    OrangeBeanie,

    LightBoots,

    Sneakers2,

    Beanie2,

    HeatPack,

    RepairBow,

    RoachBuilder,

    JeepBuilder,

    Shotgun,

    ColdPack,

    AutomaticDrill,

    Spear,

    WinterJacket,

    WinterJacketRed,

    Metal2Ore,

    Metal3Ore,

    Metal4Ore,

    ShapedMetal2,

    ShapedMetal3,

    ShapedMetal4,

    MondiniumPick,

    MineBow,

    StonePickaxe,

    CheapoPants,

    ShittyTshirt,

    Beacon,

    GoatBuilder,

    C4Explosive,

    SpearThrow,

    PowerBow2,

    Gasoline,

    Magnet,

    Fridge,

    FrozenRawSteak,

    FrozenCookedSteak,

    CrudeCoolant,

    PitcherPlantSeeds,

    Campfire,

    Dynamite,

    VehicleAttachmeTest,

    PaintTest,

    PaintRed,

    PaintBlue,

    PaintGreen,

    PaintWhite,

    RoachTripleDoors,

    Roach44GalArmor,

    RoachSkullBar,

    RoachRoofLights,

    LargeTractorWheel,

    SmallCartWheel,

    LooseSuspension,

    MediumSuspension,

    TightSuspension,

    WeakEngine,

    MediumEngine,

    PowerfullEngine,

    RoachStockGearbox,

    RoachRoadGearbox,

    DamagedEngine,

    RoachStripeMask,

    RoachDefaultPaintMask,

    RoachDoubleStripeMask,

    GoatCamoMask,

    GoatFlamesMask,

    GoatSideStripeMask,

    GoatSkullMask,

    GoatWheelNipples,

    GoatJudgeFront,

    GoatJudgeBack,

    GoatStasherFront,

    GoatStasherBack,

    GoatCowlingFront,

    GoatRacerBackpanel,

    ShotgunShell,

    DriftLargeWheel,

    RoachFrontSeat,

    SharkWeekBumper,

    SharkWeekFront,

    SharkWeekSide,

    SharkWeekRoof,

    SharkWeekBack,

    ChaserBumper,

    ChaserFront,

    ChaserSide,

    ChaserRoof,

    ChaserBack,

    Roach1986PaintMask,

    RoachDigiCamoMask,

    RoachEyesMask,

    RoachGraffMask,

    PaintSandy,

    PaintGrass,

    PaintDarkGrey,

    PaintMediumGrey,

    PaintArmyGreen,

    Sunscreen,

    AussieHat,

    SucculentSeeds,

    FlannelShirt,

    Singlet,

    SingletBlue,

    StackHat,

    Sombrero,

    Mullet,

    GoatTwinStripesMask,

    GoatFlatMask,

    GoatMazeMask,

    AssaultRifleSemi,

    SpearIce,

    SpearMolten,

    SpearGreen,

    ArcticPelt,

    SasquachPelt,

    DetonatorCap,

    Paint001,

    Paint002,

    Paint003,

    Paint004,

    Paint005,

    Paint006,

    Paint007,

    Paint008,

    Paint009,

    Paint010,

    Paint011,

    Paint012,

    Paint013,

    Paint014,

    Paint015,

    Paint016,

    Paint017,

    Paint018,

    Paint019,

    Paint020,

    Paint021,

    Paint022,

    Paint023,

    Paint024,

    Paint025,

    Paint026,

    Paint027,

    Paint028,

    Paint029,

    Paint030,

    Paint031,

    Paint032,

    Paint033,

    Paint034,

    Paint035,

    Paint036,

    Paint037,

    YetiHorn,

    Feather1,

    Feather2
GroundLog,

    Tree,

    PlainRock,

    IronRock,

    Limestone,

    Shigi,

    Cotton,

    Owrong,

    Coal,

    RedRock,

    ClayBlock,

    Shepherd,

    TealRock,

    FlintRock,

    TestBoltAction,

    Rafaga,

    Tokar,

    Bor,

    None,

    ConsumableLootCrate,

    WeaponLootCrate,

    CommonLootCrate,

    AutomaticDrill,

    Metal2,

    Metal3,

    Metal4,

    Driftwood,

    GroundFlint,

    TokarAlbino,

    PitcherPlant,

    OilDrill,

    ExplodableRock1,

    ForestShigi,

    RoachChassis,

    GoatChassis,

    ParrotTokar,

    BlueTokar,

    WolfShigi,

    AcrticShigi,

    TropicalForrestShigi,

    RadiationBor,

    SucculentPlant,

    Yeti,

    Bigfoot