The plugin automatically kick players with less than 4 characters in the name.


You can withlist somebody, just give him the "noname.allowed" permission (admins are automatically added to the whitelist)


For it use:

````
grant user <name> noname.allowed

revoke  user <name> noname.allowed

grant group <name> noname.allowed
````