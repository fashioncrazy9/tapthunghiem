**Command :**


/god <playername>

/ungod <playername>


**Permission :**


advgod.allowed


**Credits : **


all credit to my xBDMx partner, the code and is always helping.

**Permission console :**


oxide.grant user <playername> advgod.allowed

oxide.revoke user <playername> advgod.allowed