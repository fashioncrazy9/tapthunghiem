**Welcome Message **to welcome a player to the server.

**Configuration**:
Code (Java):
````
{

  "Messages": [

    "<size=17><silver>Welcome <lime>{player}<end><end></size>",

    "<silver><orange><size=20>•</size><end> Type <orange>/help<end> for all available commands.<end>",

    "<silver><orange><size=20>•</size><end> Be respectful to other players.<end>"

  ]
}
````


**Video Tutotial:**

- [French Tutorial by](https://www.youtube.com/watch?v=PZvTfeLbFsQ): [@Zatieu82](http://oxidemod.org/members/100312/)