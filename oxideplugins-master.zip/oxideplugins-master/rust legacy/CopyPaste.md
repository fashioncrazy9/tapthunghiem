Copy Paste is back for Oxide 2.0 on Legacy



**Features:**

- Building paste **rotates** depending on your **eyes' angle**

- Save all **Deployables**

- Save all **Inventories**

**Commands:**
- /copy NAME => copy the building, the building part that you will choose will serve as structure 0 for when you paste it (so be careful of which part you look at while you use this command)
- /paste NAME optional:HeightAdjustment => paste a building
- /placeback NAME => placeback a building where it was when it was saved