**When a player joins the server
**

Everyone sees:
customChatName : playerName has connected to the server.


If MOTD enabled the player that connects will see:

    Please read the server rules by typing /rules.

**When a player leaves the server**


Everyone sees:
customChatName : playerName has disconnected from the server.

All of the above messages can be configured and the MOTD can be disabled.