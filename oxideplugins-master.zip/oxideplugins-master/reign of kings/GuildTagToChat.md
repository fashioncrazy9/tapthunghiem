This plugin adds the player's guild tag to his chat message.

**Notes:**

After someone changes the color in the config, the first time that he will send a message he will have the color that was set before.

The second message should work fine.

**Default Configuration:**

````
{

  "GuildTagColor": "[FF0000]"

}
````


**Next Update:**

Enable/Disable option in config to allow enabling and disabling the plugin.