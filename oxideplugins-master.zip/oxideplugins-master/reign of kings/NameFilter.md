This plugin will kick players from the server when they connect with a name with weird characters in.


This is a temporary version, an update will be available in the next couple of days that will allow you to easily change the allowed characters and the kick message through a config file.