Automatically kicks players who are using a name that already exist to stop name cloning. So you can no longer have multiple players with the same name.


You may grant the permission "noclone.bypass" to exclude them from the autokick.