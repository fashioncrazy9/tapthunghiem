**Chat Commands:**

- /players
**Oxide Permissions:**

default is: "**canplayerslist**"

to let players see the players list you must do: 
````
/grant group default canplayerslist
````


**Default Config:**

````
{

  "Message - Admin Color": "orange",

  "Message - Footer": "====================",

  "Message - Header": "=== Players List ===",

  "Message - Max characters per line": 50,

  "Message - Player Color": "green",

  "Permission - Oxide Permissions": "canplayerslist"

}
````