**Admin Chat **allows you to chat in a admin chatroom.

**Permissions (RoK):**


* canAdminChat


**Admin Commands:**


* 
**/a [message] **- writes a message in the admin chatroom


**Known issues:**


* none


**Config file:**


* none


**Future Updates:**


* @Message in the chat
* /a admin chat toggling
* your suggestions

[](http://phc-rust.jimdo.com/donations/)