Fly Mode is a plugin that allows the players that have been set as server administrator or have the required Oxide permission. When one of the above requirements is set the player will have access to the ingame chat command **/fly**


This command will allow the player to fly around freely at increased speed using the default input keys to move and the mouse to point at the direction to move in.


The speed can be doubled by holding the Sprint button and halved by toggling the Crouch button.

**Permissions**


This plugin requires the user to be set as admin or have the oxide permission **fly.allowed
**