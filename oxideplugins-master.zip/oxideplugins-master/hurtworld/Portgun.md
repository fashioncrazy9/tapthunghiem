Teleport to where you are looking at.
**Commands:**

- /p => will teleport you where you are looking at

- /up XX => Go up of Xm

- /forward XX => Go forward of Xm

- /right XX => Go right of Xm
**Permissions:**

portgun.use