Makes screenshot testing really easy for admins by telling the player what to do and enable branding on their client just by typing in one command.

````
Oxide permission: "screenshotrequest"

oxide.grant user <name> screenshotrequest

oxide.revoke user <name> screenshotrequest
````


````
Default message: "Take a screenshot with F12 and upload it to Steam."
````

Can now be changed in the configuration file if you so wish!


Command is: /sr <name>

I hope you all enjoy my plugin!