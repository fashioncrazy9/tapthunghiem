Usage:

````
/insult me -- insult yourself

/insult playername -- insult another player
````

Permission:

````
insultgenerator.use

oxide.grant user spice insultgenerator.use
````

Any questions? Add me on Steam [here.](http://steamcommunity.com/id/spicy_)