Clear you're own inventory or admins can clear other players

great for vip kits and making kits, this wipes your whole inventory including armor and things on you're hotbar

**How to use**

/clearinv - clears you're whole inventory

/clearinv "playername" - clears another players - needs permission

**Permission**

/clearinv - everyone can use

/clearinv "playername" - needs permission inventoryclearer.allowed


grant.user "playername" inventoryclearer.allowed

revoke.user "playername" inventoryclearer.allowed

**Credits**

Reneb - looked through his admin>player plugin

mvrb - pretty much fixed every problem and just a nice guy

**Things to add**

/clearall - for events

will add messages


Any feedback and criticism is helpful!