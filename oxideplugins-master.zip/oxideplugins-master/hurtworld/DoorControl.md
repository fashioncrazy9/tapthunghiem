**Permission:**

doorcontrol.admin

**How to Add Permission:**

/grant user UserName doorcontrol.admin

or

/grant group admin doorcontrol.admin (If you have an admin group)

**Commands:**

/doors [open/close] [distance](optional)


Example: /doors open 20

This will open all doors within 20 meters of you.


Example: /doors open

This will open all doors on the server.