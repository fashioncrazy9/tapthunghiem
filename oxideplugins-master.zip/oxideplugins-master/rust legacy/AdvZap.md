This plugin takes the commonly used and enjoyed "Freeze" plugins idea of not allowing a player to move and makes it permanent until removed or the player leaves. This plugin doesn't use key binds to remove player movement, it tells the client that it is dead while telling the server that is it "to dead" making the player unable to move and be stuck with 0 control. This will have more functionality in the future as well as possibly implemented in a bigger plugin I'm working on.


Commands:

/zap "username"

/unzap "username"