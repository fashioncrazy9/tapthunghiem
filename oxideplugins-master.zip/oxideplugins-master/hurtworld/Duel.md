**PLEASE CONSIDER DONATING TO SUPPORT DEVELOPMENT**

This will allow users to battle one another by requesting duels for cash. Server admins can even create a dedicated arena for these duels.

**Setup commands:**
If the below aren't set, it will teleport the players to a random spawn point
**/duel setup arena p1** = This sets player1's location (Where you are standing at)
**/duel setup arena p2** = This sets player2's location (Where you are standing at)

**Usage Commands:

/duel req** <playername> <wageramount> - Requests a duel
**/duel yes** <playername> - Accepts a duel (Playername is optional)
**/duel no **- Declines a duel
**/duel top** - displays top 5 duelers by wins

**SPECIAL THANKS**
[@kpl35mm-NL](http://oxidemod.org/members/93043/) for helping to beta test the plugin. You assistance is much appreciated.