I have edited Reneb's share database and made a plugin for friends system.


/addfriend "name" - To add friends to your friend list.

/unfriend  "name" - To delete a friend.


Credits goes to Reneb.