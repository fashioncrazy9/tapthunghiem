This plugin allows you to ban players by their IP address.

**Permissions:

canbanip or rcon admin to banip's

canunbanip or rcon admin to unbanip's

canbanslpip  or rcon admin to ban offline player's

ipbanimunity **or rcon admin **to be immuned to ipbans**




for those of you looking for an anticheat that does ip bans you can try renebes : R-Anticheat v 2.0.14 i modified to do ip bans banip plugin is needed
[MEGA](https://mega.nz/#!dV4QlTra!b3KO7qS1iP26pZCu8pznkCR9MmExTjXI1az3AKAe4SY)

**Chat Commands:

/ipwl "playername must be precise, used to whitelist id's

/banslp "playername must be precise, used to do offline bans(should log all needs to be enabled)

/ipbanlist to view banlist in pages

/ebp playername to view all banned players with that name pages is optional.

/banip playername "reason(optional)must use quotes for multiple words

/unbanip ip or name to unban a ip**


remember the quotes are neccesare for example whitelisting a player with spaces in his name say the boss you would have to do /ipwl "the boss or /ipwl "the boss"


If you wish to show me some love add me on steam and donate a steamgame to me