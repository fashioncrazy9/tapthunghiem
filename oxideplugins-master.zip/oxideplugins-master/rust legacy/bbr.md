**Permissions Needed:**

Rbb.checkbase or rcon admin

**Chat Commands**

/rbb - Obliterate all banned owner bases in your server


/cb - to check if the base you are looking at has a banned owner


/cbl index optional- to see all banned owner bases in your server in a verry nice looking list the base number is what you use to tp when using tbb


/tpbb  BaseNumber- to teleport to a banned owner base with the base number