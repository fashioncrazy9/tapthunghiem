Great for finding espers, hackers who toggle when they see you nearby, or just admining without making any footsteps, sounds, etc.

**Command:**

/s - Leave your body and start spiritwalking, and again to return to your body.

**Permission:**

grant user [name] canspirit


This is an updated version of [@Pretermit](http://oxidemod.org/members/40816/) plugin for Oxide 2. Thankyou [@Bond... James Bond](http://oxidemod.org/members/12279/) for the configuration


Here is an example of me banning someone while streaming with this plugin for having ESP.