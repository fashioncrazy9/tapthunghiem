Vanilla Extract Give Command


Give yourself or others items using:

/give [optional: Playername] <itemname> [optional: amount]


Give everyone items by using:

/giveall <itemname> [optional: amount]


If you have kits installed you can give yourself or others a kit by using:

/givekit [optional: Playername] <kitname>


Or if you want to give everyone a kit:

/giveall kit <kitname>


Permissions:

cangive

all

OR logged into rcon