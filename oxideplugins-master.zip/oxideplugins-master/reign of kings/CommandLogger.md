This plugin will log all chat events (normal chat and guild chat) and also all the chat commands that are used to separate files.


Keep in mind that all commands that are being logged also those that do not exist or don't do anything for the player so even if someone would type /fly without having access to the command or /randomunexistingcommand, it will still show up in the log.