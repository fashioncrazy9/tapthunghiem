This plugin is an alternative version of the Reign of Kings give function where if someone doesn't like the RoK's give system then he can simply use this one.

**Commands:**

/pgive help => Shows the available give commands.

/pgive to <PlayerName> <ItemName> <ItemStack> => Gives the item and the amount to the target.

/pgive <ItemName> <ItemStack> => Gives the item and the amount to the player who used the command.

**Permission for the commands listed above:**

"**cangive**" for all the commands.