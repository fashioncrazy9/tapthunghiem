**OXIDE PERMISSION**: flag is "admin"


Easily Switch between Admin and player mode!


/admin => turn into an admin

/admin => turn back into a player

/admin hide => activate/deactivate the name hide

/admin name XXX => set your admin name, default: SERVER CONSOLE

**What is new?**

- It **saves your entire inventory** as it is, with weapon mods, weapon bullets, etc, and switchs your inventory and armor to admin stuff!

Then when you get back to a player you loose all your admin gear and get back all your player stuff.

- **no falldamage**, you wont get injured

- godmode that will make you able to **run into water**

- **choose your admin gear**


This makes you able to quickly switch from player mod to admin mod without having to go back to base


**INVISIBLE NAME (AS STEAM NAME!!!):** "ᅠᅠᅠ"


default cfg file: cfg_admin-player.txt

````

{

  "Version":"1.2.6",

  "Armor":["Invisible Helmet","Invisible Vest","Invisible Pants","Invisible Boots"],

  "BagPack":[{

      "amount":50,

      "name":"Arrow"

    }],

  "FastBar":[{

      "amount":1,

      "name":"Uber Hatchet"

    },{

      "amount":1,

      "name":"Uber Hunting Bow"

    },{

      "amount":5,

      "name":"Cooked Chicken Breast"

    },{

      "amount":5,

      "name":"Large Medkit"

    },{

      "amount":1,

      "name":"Stone Hatchet"

    }]

}

 
````