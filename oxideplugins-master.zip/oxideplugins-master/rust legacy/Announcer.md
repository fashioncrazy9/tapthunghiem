This is a simple plugin that allows you to send some basic information to the in-game chat. Each function of the plugin can be disabled or enabled through the configuration file, by default all the components are enabled.


The plugin consists of 3 components:

- Join/Leave messages: Each time a player joins or leaves a message is printed in the chat for everyone to see.

- Broadcasts: Allows you to broadcast a line of text to all players on a pre-defined interval.

- Rules: Adds a /rules command which shows all the set rules to the player using the command.