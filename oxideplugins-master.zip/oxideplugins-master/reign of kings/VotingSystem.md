**Concept**


Any player can start a vote and after the vote commenced, there are a few seconds for other players to vote too. After the time is over, if the percentage of the players who voted yes equals/bigger than 50% the vote will pass. Once the vote has passed there is a few minutes minutes cooldown before the someone can vote again.

Both the vote duration and the cooldown duration can be changed in the config file.

You can change the messages sent by the plugin in the config file in the Lang folder.


**Commands**


/voteday - Will start a vote to set the time to day.

/votenight - Will start a vote to set the time to night.

/votewclear - Will start a vote to clear he weather.

/votewheavy - Will start a vote to make it storm.

(/y)es - Vote yes.

(/n)o - Vote no.

**Troubleshooting**


If you happen to come across any bugs please let me know and I'll try to fix it as soon as possible.