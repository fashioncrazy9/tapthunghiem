**Permission:**

areanuke.admin

**How to Add Permission:**

/grant user UserName areanuke.admin

or

/grant group admin areanuke.admin (If you have an admin group)

**Commands:**

/areanuke [range]


Example: /areanuke 20

This will remove every object within 20 meters of you.