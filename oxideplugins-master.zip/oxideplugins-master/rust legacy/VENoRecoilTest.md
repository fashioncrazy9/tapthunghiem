Still working on a few things but at the moment:


/recoiltest "PlayerName" Will set the player's mouse speed to 0 and rebinds all movement keys. W and Mouse0 will trigger weapon fire. By doing this, it is possible to see for certain if a player has recoil.


/testend "PlayerName" Will reset the mouse speed and key bindings to default.


WORKING ON:


* S̶a̶v̶i̶n̶g̶ ̶p̶l̶a̶y̶e̶r̶'̶s̶ ̶k̶e̶y̶ ̶b̶i̶n̶d̶i̶n̶g̶s̶ ̶b̶e̶f̶o̶r̶e̶ ̶t̶h̶e̶ ̶t̶e̶s̶t̶ ̶t̶o̶ ̶r̶e̶b̶i̶n̶d̶ ̶t̶h̶e̶m̶ ̶a̶f̶t̶e̶r̶ ̶t̶o̶ ̶t̶h̶e̶i̶r̶ ̶c̶u̶s̶t̶o̶m̶ ̶s̶e̶t̶t̶i̶n̶g̶s̶.̶   ✔
* Saving player's inventory, clearing it and making a gun active for the test and replacing the saved inventory after the test.
* Automatically checking to see if eye angle changes after firing.
* Configurable random tests or tests on first join
* Configurable ban or send to jail on test fail


Permisions:

canrecoiltest, all or logged into rcon