In this plugin you will be able to heal yourself/ other players, cure yourself/other players, feed yourself/other players, poison yourself/other players, starve yourself/other players, apply rads to yourself/other players, and kill yourself/other players.


There is also a built in help menu accessible through /advmetahelp

Further information can be found on the faq page about specific commands and syntax.

**Permission:** advmetabolism.allowed

Use of this permission: grant user/group "Name" advmetabolism.allowed

**Commands:**

/feed

/feed 'user'

/heal

/heal 'user'

/starve

/starve 'user'

/rad

/rad 'user'

/poison

/poison 'user'

/cure

/cure 'user'

/kill

/kill 'user'

/vitals 'user'