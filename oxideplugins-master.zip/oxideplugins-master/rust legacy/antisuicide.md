Prevents players from being able to suicide.


need flags canantisuicide or rcon admin

**Chat Commands:**


* 
**/sactive** to activate
* 
**/sdeactive** to deactivate
* /sactivepl playername to activate on that player
* /sdeactivepl playername to deactivate on that player

Remade by copper for Oxide 2.0, original plugin in Oxide 1 by D4K1NG.