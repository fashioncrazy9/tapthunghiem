Enabled means the AntiDecay is enabled on that object.


One more thing for all of you using decay.decaytickrate then setting it to 0 or some thing less than default value that makes your decay go way faster decay.decaytickrate 1 will decay every 1 second vice versa set it back to default so the moddamage hook doesnt get called every 0.00001 seconds that could possibly lag your server xD