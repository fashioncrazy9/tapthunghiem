Allows admins to mute all players in the chat.


Permission: canmuteall


Usage:

````
oxide.grant user Spicy canmuteall

oxide.revoke user Spicy canmuteall

oxide.grant group admin canmuteall

oxide.revoke group admin canmuteall


/muteall - globally mutes chat.

/muteall - again globally unmutes chat.
````