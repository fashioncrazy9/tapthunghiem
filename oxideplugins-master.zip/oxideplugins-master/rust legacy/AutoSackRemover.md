This plugin will automatically remove the loot sack when players die

**Features:**

- Choose to **delay **removing the sack if a player is **looting **it

- **Choose the time** for the sack to be removed

- Easily **activate /deactivate** the plugin

**Commands:**

- /sackremover => Activate or deactivate the auto sack remover


Configs: AutoSackRemover.json

````
{

  "Settings: activate plugin": true,

  "Settings: dont remove if being looted": true,

  "Settings: time before removing the loot sack": 1

}
````