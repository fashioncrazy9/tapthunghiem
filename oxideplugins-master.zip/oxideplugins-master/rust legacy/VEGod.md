Vanilla Extract God Command:


/god - toggle god mode


god mode is deactivated automatically on disconnect


Permissions:

cangod

all

OR

logged into RCon