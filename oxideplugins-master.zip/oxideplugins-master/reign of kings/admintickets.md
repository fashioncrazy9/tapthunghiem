**Admin Reports** gives players the opportunity to send a message to admins, admins can see those with position etc. Good for reporting exploited bases, bad symbols on signs and more.

**Permissions (RoK permissions):**


* isTicketsAdmin - for all admin commands (Suggest better permission name please)


**Commands:**


* /ticket - shows all availiable commands depending if the player has the admin permission
* /ticket message - Saves a message in the Report list.


**Admin Commands:**


* /ticket list - shows the list of saved reports
* /ticket clear - clears the list of reports
* /ticket view [id] - shows the report with the specified id
* /ticket remove [id] - removes the report with the specified id


**Known issues:**


* none


**Config file:**


* none


**Future updates:**

- position tracking like in the Rust version of this plugin

- your suggestions

[](http://phc-rust.jimdo.com/donations/)