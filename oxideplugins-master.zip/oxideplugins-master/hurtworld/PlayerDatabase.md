This plugin is useless alone

I will be porting plugins to use this lightweight database after couple testings
**READ TO INSTALL:**

in: **server/serveridentity/oxide/data

create a folder** named: **playerdatabase**
**How to reset the data:**

1) Shutdown the server

2) delete: oxide/data/PlayerDatabase.json

3) empty the folder: playerdatabase

4) restart your server