Set the gather multiplier to change how fast you gather something (i've set the default values in the config)


Set the resource multiplier to give more of those items, or not.

can't reduce to less then 1 ^^ (no idea what would happen if you set it to 0 )


Numbers can't have decimals


Default config: GatherMultiplier.json

````
{

  "Gather Multiplier: Animals": 2,

  "Gather Multiplier: Metal Rock": 3,

  "Gather Multiplier: Stone Rock": 3,

  "Gather Multiplier: Sulfur Rock": 3,

  "Gather Multiplier: WoodPile": 10,

  "Resource Multiplier": {

    "Animal Fat": 1,

    "Blood": 1,

    "Cloth": 1,

    "Leather": 1,

    "Metal Ore": 1,

    "Raw Chicken Breast": 1,

    "Stones": 1,

    "Sulfur Ore": 1,

    "Wood": 1

  }

}
````